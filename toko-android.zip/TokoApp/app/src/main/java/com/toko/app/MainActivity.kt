@file:OptIn(ExperimentalMaterial3Api::class)
package com.toko.app

import android.content.*
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Base64
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.*
import kotlinx.coroutines.*
import org.json.*
import java.net.*
import java.text.NumberFormat
import java.util.Locale

object Api {
    var base = ""
    init { CookieHandler.setDefault(CookieManager()) }
    suspend fun call(a: String, body: JSONObject? = null, qs: String = ""): Any = withContext(Dispatchers.IO) {
        val c = URL("$base/api.php?a=$a$qs").openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 20000
        if (body != null) {
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
        }
        val s = (if (c.responseCode < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        val j = JSONTokener(s).nextValue()
        if (j is JSONObject && j.has("error")) throw Exception(j.getString("error"))
        j
    }
}
val LV = mapOf("user" to 1, "kasir" to 2, "admin" to 3, "owner" to 4)
fun JSONArray.list() = (0 until length()).map { getJSONObject(it) }
fun JSONObject.str(k: String, d: String = "-") = if (isNull(k)) d else getString(k)
fun rp(n: Double): String = "Rp " + NumberFormat.getInstance(Locale("id", "ID")).format(n)
fun CoroutineScope.go(c: Context, f: suspend () -> Unit) = launch {
    try { f() } catch (e: Exception) { Toast.makeText(c, e.message ?: "Gagal", Toast.LENGTH_LONG).show() }
}
fun bmp(s: String): ImageBitmap? = try {
    val b = Base64.decode(s.substringAfter(","), Base64.DEFAULT)
    BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = 4 }).asImageBitmap()
} catch (e: Exception) { null }
suspend fun struk(ctx: Context, id: Int, store: String) {
    val o = Api.call("receipt", null, "&id=$id") as JSONObject
    val l = o.getJSONArray("items").list().joinToString("\n") {
        "${it.getString("name")}\n  ${it.getInt("qty")} x ${rp(it.optDouble("price"))} = ${rp(it.optDouble("price") * it.getInt("qty"))}"
    }
    var t = "$store\n#${o.getInt("id")} ${o.getString("created_at")}\nKasir: ${o.str("cashier")}\n--------------------\n$l\n--------------------\n" +
        "TOTAL: ${rp(o.optDouble("total"))}\nMetode: ${o.str("method")}\nStatus: ${if (o.getInt("paid") == 1) "LUNAS" else "BELUM LUNAS"}"
    if (o.getString("source") == "pos") t += "\nDiterima: ${rp(o.optDouble("paid_amount"))}\nKembali: ${rp(o.optDouble("paid_amount") - o.optDouble("total"))}"
    t += "\n\nTerima kasih"
    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, t) }, "Bagikan struk"))
}

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App(getSharedPreferences("p", 0)) } } }
    }
}

@Composable fun Img(s: String, m: Modifier) {
    val b = remember(s) { bmp(s) }
    if (b != null) Image(b, null, m, contentScale = ContentScale.Crop) else Box(m.background(Color(0xFFDDDDDD)))
}

@Composable fun App(p: SharedPreferences) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var u by remember { mutableStateOf<JSONObject?>(null) }
    var st by remember { mutableStateOf(JSONObject()) }
    var ready by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) }
    val cart = remember { mutableStateMapOf<Int, Int>() }
    val prods = remember { mutableStateListOf<JSONObject>() }
    LaunchedEffect(Unit) {
        Api.base = p.getString("srv", "")!!
        try { if (Api.base.isNotEmpty()) { val r = Api.call("me"); if (r is JSONObject) u = r } } catch (e: Exception) {}
        ready = true
    }
    LaunchedEffect(u) { try { if (Api.base.isNotEmpty()) st = Api.call("settings") as JSONObject } catch (e: Exception) {} }
    if (!ready) return
    val me = u
    if (me == null) { Auth(p) { u = it; tab = 0 }; return }
    val role = me.getString("role"); val staff = LV[role]!! >= 2
    val tabs = if (staff) listOf("Pesanan", "POS") + (if (role == "owner") listOf("Dashboard") else listOf()) else listOf("Produk", "Keranjang", "Pesanan", "Berita")
    val store = st.str("store_name", "Toko"); val logo = remember(st.str("logo", "")) { bmp(st.str("logo", "")) }
    Scaffold(
        topBar = { TopAppBar(
            title = { Row(verticalAlignment = Alignment.CenterVertically) {
                if (logo != null) Image(logo, null, Modifier.size(32.dp).padding(end = 8.dp))
                Text(store) } },
            actions = { TextButton({ sc.go(ctx) { Api.call("logout", JSONObject()); u = null } }) { Text("Keluar") } }) },
        bottomBar = { NavigationBar { tabs.forEachIndexed { i, t ->
            NavigationBarItem(tab == i, { tab = i }, {}, label = { Text(t, maxLines = 1, fontSize = 11.sp) }) } } }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tabs[tab]) {
                "Produk" -> Produk(cart, prods)
                "Keranjang" -> Keranjang(cart, prods) { tab = 2 }
                "Pesanan" -> if (staff) Kelola(store) else PesananSaya(st)
                "Berita" -> Berita()
                "POS" -> Pos(store)
                "Dashboard" -> Dash()
            }
        }
    }
}

@Composable fun Auth(p: SharedPreferences, ok: (JSONObject) -> Unit) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var srv by remember { mutableStateOf(p.getString("srv", "")!!) }
    var em by remember { mutableStateOf("") }; var pw by remember { mutableStateOf("") }
    var nm by remember { mutableStateOf("") }; var reg by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.Center) {
        Text(if (reg) "Daftar" else "Masuk", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(srv, { srv = it }, label = { Text("Alamat server, mis. https://situs.com/toko") }, modifier = Modifier.fillMaxWidth())
        if (reg) OutlinedTextField(nm, { nm = it }, label = { Text("Nama") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(em, { em = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pw, { pw = it }, label = { Text("Sandi") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Button({ sc.go(ctx) {
            Api.base = srv.trim().trimEnd('/'); p.edit().putString("srv", Api.base).apply()
            if (reg) {
                val r = Api.call("register", JSONObject().put("name", nm).put("email", em).put("pass", pw)) as JSONObject
                Toast.makeText(ctx, r.getString("msg"), Toast.LENGTH_LONG).show(); reg = false
            } else ok(Api.call("login", JSONObject().put("email", em).put("pass", pw)) as JSONObject)
        } }, Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("Kirim") }
        TextButton({ reg = !reg }) { Text("Masuk / Daftar") }
    }
}

@Composable fun Produk(cart: SnapshotStateMap<Int, Int>, prods: SnapshotStateList<JSONObject>) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    LaunchedEffect(q) { sc.go(ctx) { val a = Api.call("products", null, "&q=" + URLEncoder.encode(q, "UTF-8")) as JSONArray; prods.clear(); prods.addAll(a.list()) } }
    Column {
        OutlinedTextField(q, { q = it }, label = { Text("Cari produk") }, modifier = Modifier.fillMaxWidth().padding(8.dp))
        LazyVerticalGrid(GridCells.Fixed(2), contentPadding = PaddingValues(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            gridItems(prods) { p ->
                val id = p.getInt("id")
                Card { Column(Modifier.padding(8.dp)) {
                    Img(p.str("image", ""), Modifier.fillMaxWidth().height(100.dp))
                    Text(p.getString("name"), fontWeight = FontWeight.Bold)
                    Text(rp(p.optDouble("price")), color = Color(0xFF2E7D32))
                    Text("Stok: ${p.getInt("stock")}", fontSize = 12.sp)
                    Button({ cart[id] = (cart[id] ?: 0) + 1 }, enabled = p.getInt("stock") > 0, modifier = Modifier.fillMaxWidth()) { Text(if (p.getInt("stock") > 0) "+ Keranjang" else "Habis") }
                } }
            }
        }
    }
}

@Composable fun Keranjang(cart: SnapshotStateMap<Int, Int>, prods: List<JSONObject>, done: () -> Unit) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    val rows = cart.entries.mapNotNull { e -> prods.find { it.getInt("id") == e.key }?.let { it to e.value } }
    val total = rows.sumOf { it.first.optDouble("price") * it.second }
    Column(Modifier.padding(12.dp)) {
        LazyColumn(Modifier.weight(1f)) { items(rows) { (p, n) ->
            val id = p.getInt("id")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(p.getString("name"), Modifier.weight(1f))
                TextButton({ if (n > 1) cart[id] = n - 1 else cart.remove(id) }) { Text("-") }
                Text("$n")
                TextButton({ cart[id] = n + 1 }) { Text("+") }
                Text(rp(p.optDouble("price") * n))
            }
        } }
        Text("Total: ${rp(total)}", style = MaterialTheme.typography.titleLarge)
        Button({ sc.go(ctx) {
            Api.call("checkout", JSONObject().put("items", JSONArray(rows.map { JSONObject().put("id", it.first.getInt("id")).put("qty", it.second) })))
            cart.clear(); Toast.makeText(ctx, "Pesanan dibuat. Bayar di tab Pesanan.", Toast.LENGTH_LONG).show(); done()
        } }, enabled = rows.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Pesan") }
    }
}

@Composable fun PesananSaya(st: JSONObject) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var o by remember { mutableStateOf(listOf<JSONObject>()) }
    var pf by remember { mutableStateOf<Pair<Int, String>?>(null) }
    fun load() { sc.go(ctx) { o = (Api.call("myorders") as JSONArray).list() } }
    LaunchedEffect(Unit) { load() }
    pf?.let { (id, m) -> AlertDialog(onDismissRequest = { pf = null },
        title = { Text("Pembayaran: $m") },
        text = { Column {
            if (m == "transfer") Text(st.str("pay_info", "").ifBlank { "Hubungi toko untuk nomor rekening." })
            else if (m == "qris") { val q = st.str("qris", ""); if (q.isNotEmpty()) Img(q, Modifier.size(220.dp)) else Text("QRIS belum diatur.") }
            else Text("Bayar tunai saat barang diterima.") } },
        confirmButton = { TextButton({ sc.go(ctx) { Api.call("pay", JSONObject().put("id", id).put("method", m)); pf = null; load() } }) { Text("Konfirmasi") } },
        dismissButton = { TextButton({ pf = null }) { Text("Batal") } }) }
    LazyColumn(contentPadding = PaddingValues(8.dp)) { items(o) { x ->
        val id = x.getInt("id")
        Card(Modifier.fillMaxWidth().padding(bottom = 8.dp)) { Column(Modifier.padding(12.dp)) {
            Text("#$id · ${rp(x.optDouble("total"))}", fontWeight = FontWeight.Bold)
            Text("${x.getString("status")} · ${listOf("Belum bayar", "Lunas", "Menunggu verifikasi")[x.getInt("paid")]}")
            Text(x.getJSONArray("items").list().joinToString { it.getString("name") + " ×" + it.getInt("qty") }, fontSize = 12.sp)
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                if (x.getInt("paid") == 0 && x.getString("status") == "baru")
                    listOf("transfer", "qris", "cod").forEach { m -> Button({ pf = id to m }, Modifier.padding(end = 4.dp)) { Text(m) } }
                TextButton({ sc.go(ctx) { struk(ctx, id, "Struk") } }) { Text("Struk") }
            }
        } }
    } }
}

@Composable fun Berita() {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var n by remember { mutableStateOf(listOf<JSONObject>()) }
    LaunchedEffect(Unit) { sc.go(ctx) { n = (Api.call("news") as JSONArray).list() } }
    LazyColumn(contentPadding = PaddingValues(8.dp)) { items(n) { x ->
        Card(Modifier.fillMaxWidth().padding(bottom = 8.dp)) { Column(Modifier.padding(12.dp)) {
            Text(x.getString("title"), fontWeight = FontWeight.Bold); Text(x.getString("created_at"), fontSize = 11.sp); Text(x.getString("body"))
        } }
    } }
}

@Composable fun Kelola(store: String) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var o by remember { mutableStateOf(listOf<JSONObject>()) }
    fun load() { sc.go(ctx) { o = (Api.call("orders") as JSONArray).list() } }
    fun act(a: String, id: Int, s: String? = null) { sc.go(ctx) { Api.call(a, JSONObject().put("id", id).apply { if (s != null) put("status", s) }); load() } }
    LaunchedEffect(Unit) { load() }
    LazyColumn(contentPadding = PaddingValues(8.dp)) { items(o) { x ->
        val id = x.getInt("id")
        Card(Modifier.fillMaxWidth().padding(bottom = 8.dp)) { Column(Modifier.padding(12.dp)) {
            Text("#$id · ${x.str("cust", "Walk-in")} · ${rp(x.optDouble("total"))}", fontWeight = FontWeight.Bold)
            Text("${x.getString("status")} · ${listOf("Belum bayar", "Lunas", "Menunggu verifikasi")[x.getInt("paid")]} · ${x.str("method")}")
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                listOf("diproses", "dikirim", "selesai", "batal").forEach { s -> OutlinedButton({ act("setstatus", id, s) }, Modifier.padding(end = 4.dp)) { Text(s) } }
                if (x.getInt("paid") != 1) Button({ act("verify", id) }, Modifier.padding(end = 4.dp)) { Text("Lunas") }
                TextButton({ sc.go(ctx) { struk(ctx, id, store) } }) { Text("Struk") }
            }
        } }
    } }
}

@Composable fun Pos(store: String) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var pr by remember { mutableStateOf(listOf<JSONObject>()) }
    val c = remember { mutableStateMapOf<Int, Int>() }
    var m by remember { mutableStateOf("tunai") }; var rc by remember { mutableStateOf("") }; var shift by remember { mutableStateOf(false) }
    fun load() { sc.go(ctx) { pr = (Api.call("products") as JSONArray).list(); shift = Api.call("shift") is JSONObject } }
    LaunchedEffect(Unit) { load() }
    val total = c.entries.sumOf { e -> (pr.find { it.getInt("id") == e.key }?.optDouble("price") ?: 0.0) * e.value }
    Column(Modifier.padding(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (shift) "Shift aktif" else "Shift belum dibuka", Modifier.weight(1f))
            Button({ sc.go(ctx) { Api.call(if (shift) "shift_close" else "shift_open", JSONObject()); load() } }) { Text(if (shift) "Tutup shift" else "Buka shift") }
        }
        LazyColumn(Modifier.weight(1f)) { items(pr) { p ->
            val id = p.getInt("id")
            Row(Modifier.fillMaxWidth().clickable { c[id] = (c[id] ?: 0) + 1 }.padding(8.dp)) {
                Text("${p.getString("name")} (${p.getInt("stock")})", Modifier.weight(1f)); Text(rp(p.optDouble("price"))); Text("  ×${c[id] ?: 0}")
            }
        } }
        Text("Total: ${rp(total)}", style = MaterialTheme.typography.titleLarge)
        Row { listOf("tunai", "qris", "transfer").forEach { FilterChip(m == it, { m = it }, { Text(it) }, Modifier.padding(end = 4.dp)) } }
        if (m == "tunai") {
            OutlinedTextField(rc, { rc = it }, label = { Text("Uang diterima") }, modifier = Modifier.fillMaxWidth())
            Text("Kembalian: " + rp(maxOf(0.0, (rc.toDoubleOrNull() ?: 0.0) - total)))
        }
        Row {
            Button({ sc.go(ctx) {
                val r = Api.call("pos", JSONObject().put("items", JSONArray(c.map { JSONObject().put("id", it.key).put("qty", it.value) })).put("method", m)
                    .put("received", if (m == "tunai") (rc.toDoubleOrNull() ?: 0.0) else total)) as JSONObject
                c.clear(); rc = ""; load(); struk(ctx, r.getInt("id"), store)
            } }, enabled = total > 0) { Text("Bayar & bagikan struk") }
            TextButton({ c.clear() }) { Text("Kosongkan") }
        }
    }
}

@Composable fun Dash() {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var d by remember { mutableStateOf<JSONObject?>(null) }
    LaunchedEffect(Unit) { sc.go(ctx) { d = Api.call("dash") as JSONObject } }
    d?.let { x -> LazyColumn(Modifier.padding(12.dp)) {
        item { Text("Omzet hari ini: ${rp(x.optDouble("day"))}"); Text("Omzet minggu ini: ${rp(x.optDouble("week"))}"); Text("Omzet bulan ini: ${rp(x.optDouble("month"))}")
            Text("Produk terlaris", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp)) }
        items(x.getJSONArray("top").list()) { t -> Text("${t.getString("name")} — ${t.getInt("q")} terjual") }
        item { Text("Stok menipis", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp)) }
        items(x.getJSONArray("low").list()) { t -> Text("${t.getString("name")} — sisa ${t.getInt("stock")} (min ${t.getInt("min_stock")})") }
    } }
}
