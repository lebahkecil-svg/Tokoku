TokoApp (Android native, Kotlin + Compose). Backend: folder toko (PHP/MySQL) yang sama.
Build otomatis lewat GitHub Actions; APK diunduh dari tab Actions > run terbaru > Artifacts > toko-apk.
